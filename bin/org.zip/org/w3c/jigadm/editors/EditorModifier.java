// EditorModifier.java
// $Id: EditorModifier.java,v 1.1 2008/09/16 14:14:26 sfwang Exp $
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigadm.editors ;

public interface EditorModifier {

    /**
     * Modify the selected item
     * @return The modifier item
     */

    public String modify(String item);

}
