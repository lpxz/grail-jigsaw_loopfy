// AttributeListener.java
// $Id: AttributeListener.java,v 1.1 2008/09/16 14:14:14 sfwang Exp $
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigadm.events ;

import java.util.EventListener;

public interface AttributeListener extends EventListener {

    /**
     * Invoked when the value of the Attribute has changed
     */

    public void attributeChanged(AttributeChangeEvent e);
}
