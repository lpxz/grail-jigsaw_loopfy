// UpdateHandler.java
// $Id: UpdateHandler.java,v 1.1 2008/09/16 14:12:27 sfwang Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.cvs2;

import org.w3c.cvs2.CVS;

abstract class UpdateHandler implements CVS {

    abstract void notifyEntry(String filename, int status);

}
