// $Id: CvsCommitException.java,v 1.1 2008/09/16 14:12:25 sfwang Exp $
// (c) COPYRIGHT MIT and INRIA, 1998.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.cvs2;

import org.w3c.cvs2.CvsException;

/**
 * @version $Revision: 1.1 $
 * @author  Beno�t Mah� (bmahe@w3.org)
 */
public class CvsCommitException extends CvsException {

    CvsCommitException(String filename) {
	super(filename);
    }

}
