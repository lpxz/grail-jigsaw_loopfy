// UpToDateCheckFailedException.java
// $Id: UpToDateCheckFailedException.java,v 1.1 2008/09/16 14:12:28 sfwang Exp $
// (c) COPYRIGHT MIT and INRIA, 1998.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.cvs2;

import org.w3c.cvs2.CvsCommitException;

/**
 * @version $Revision: 1.1 $
 * @author  Beno�t Mah� (bmahe@w3.org)
 */
public class UpToDateCheckFailedException extends CvsCommitException {

    UpToDateCheckFailedException(String filename) {
	super(filename);
    }

    /**
     * Get the filename.
     * @return a String.
     */
    public String getFilename() {
	return getMessage();
    }

}
