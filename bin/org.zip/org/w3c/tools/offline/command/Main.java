// Main.java
// $Id: Main.java,v 1.1 2008/09/16 14:16:05 sfwang Exp $
// (c) COPYRIGHT MIT and INRIA, 2002.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.tools.offline.command;

/**
 * A place holder for running Jigshell.
 */

public class Main {

    public static void main(String[] args) {

       	new org.w3c.tools.offline.command.CommandInterpreter(args);
    }
}
