// CommandParseException.java
// $Id: CommandParseException.java,v 1.1 2008/09/16 14:16:04 sfwang Exp $
// (c) COPYRIGHT MIT and INRIA, 2002.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.tools.offline.command;


/**
 * The command line is not a valid jigshell command
 */

public class CommandParseException extends Exception {

	public CommandParseException() {
		super("ParseError"); 
	}

}
