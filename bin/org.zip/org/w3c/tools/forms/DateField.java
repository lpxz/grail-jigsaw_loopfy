// DateField.java
// $Id: DateField.java,v 1.1 2008/09/16 14:11:38 sfwang Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.tools.forms ;

import java.awt.Panel;

import java.util.Date ;

class DateFieldEditor extends Panel {
	
}

public class DateField {
}
