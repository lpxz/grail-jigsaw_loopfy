// JpegException.java
// $Id: JpegException.java,v 1.1 2008/09/16 14:15:29 sfwang Exp $
// (c) COPYRIGHT MIT, INRIA and Keio, 1999.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.tools.jpeg;

/**
 * @version $Revision: 1.1 $
 * @author  Beno�t Mah� (bmahe@w3.org)
 */
public class JpegException extends Exception {

    public JpegException(String msg) {
	super(msg);
    }

}
