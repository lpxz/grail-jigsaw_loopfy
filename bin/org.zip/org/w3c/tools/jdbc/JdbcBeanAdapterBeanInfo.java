// JdbcBeanAdapterBeanInfo.java
// $Id: JdbcBeanAdapterBeanInfo.java,v 1.1 2008/09/16 14:15:07 sfwang Exp $
// (c) COPYRIGHT MIT, INRIA and Keio, 2000.
// Please first read the full copyright statement in file COPYRIGHT.html
package org.w3c.tools.jdbc;

/**
 * @version $Revision: 1.1 $
 * @author  Beno�t Mah� (bmahe@w3.org)
 */
public class JdbcBeanAdapterBeanInfo extends JdbcBeanInterfaceBeanInfo {
    // empty
}
