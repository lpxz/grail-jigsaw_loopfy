// InvalidRequestException.java
// $Id: InvalidRequestException.java,v 1.1 2008/09/16 14:15:52 sfwang Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.pics ;

public class InvalidRequestException extends Exception {

    public InvalidRequestException (String msg) {
	super (msg) ;
    }

}
