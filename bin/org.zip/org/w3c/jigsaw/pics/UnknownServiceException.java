// UnknownServiceException.java
// $Id: UnknownServiceException.java,v 1.1 2008/09/16 14:15:52 sfwang Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.pics ;

class UnknownServiceException extends Exception {

    UnknownServiceException (String m) {
	super (m) ;
    }

}
