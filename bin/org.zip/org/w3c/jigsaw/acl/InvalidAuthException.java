// InvalidAuthException.java
// $Id: InvalidAuthException.java,v 1.1 2008/09/16 14:15:37 sfwang Exp $
// (c) COPYRIGHT MIT, INRIA and Keio, 1999.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.acl;

/**
 * @version $Revision: 1.1 $
 * @author  Beno�t Mah� (bmahe@w3.org)
 */
public class InvalidAuthException extends Exception {

    public InvalidAuthException(String msg) {
	super(msg);
    }
}
