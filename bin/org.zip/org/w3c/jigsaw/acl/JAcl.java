// JAcl.java
// $Id: JAcl.java,v 1.1 2008/09/16 14:15:35 sfwang Exp $
// (c) COPYRIGHT MIT, INRIA and Keio, 1999.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.acl;

import java.security.acl.Acl;

import org.w3c.tools.resources.MetaDataFrame;

/**
 * @version $Revision: 1.1 $
 * @author  Beno�t Mah� (bmahe@w3.org)
 */
public abstract class JAcl extends MetaDataFrame implements Acl {

}
