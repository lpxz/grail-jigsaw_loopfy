// URLDecoderException.java
// $Id: URLDecoderException.java,v 1.1 2008/09/16 14:16:15 sfwang Exp $
// (c) COPYRIGHT MIT and INRIA, 1996.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.forms ;

public class URLDecoderException extends Exception {
    URLDecoderException (String msg) {
	super (msg) ;
    }
}


