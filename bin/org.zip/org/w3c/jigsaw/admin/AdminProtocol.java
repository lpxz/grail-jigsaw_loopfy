// AdminProtocol.java
// $Id: AdminProtocol.java,v 1.1 2008/09/16 14:13:24 sfwang Exp $
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.admin;

public interface AdminProtocol {

    public static final byte WIRED_PLAIN    = (byte) 1;
    public static final byte WIRED_FRAMED  =  (byte) 3;
}
