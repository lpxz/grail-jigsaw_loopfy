// httpdPreloadInterface.java
// $Id: httpdPreloadInterface.java,v 1.1 2008/09/16 14:11:59 sfwang Exp $
// (c) COPYRIGHT MIT, INRIA and Keio, 1999.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw.http;

/**
 * @version $Revision: 1.1 $
 * @author  Beno�t Mah� (bmahe@w3.org)
 */
public interface httpdPreloadInterface {

    /**
     * Perform some actions on the server just before startup
     * @param server the http server
     */
    public void preload(httpd server);

}
