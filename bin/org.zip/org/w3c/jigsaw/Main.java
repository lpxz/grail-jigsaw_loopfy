// Main.java
// $Id: Main.java,v 1.1 2008/09/16 14:16:10 sfwang Exp $  
// (c) COPYRIGHT MIT and INRIA, 1997.
// Please first read the full copyright statement in file COPYRIGHT.html

package org.w3c.jigsaw;

/**
 * A place holder for running Jigsaw.
 */

public class Main {

    public static void main(String args[]) {
	org.w3c.jigsaw.daemon.ServerHandlerManager.main(args);
    }

}
